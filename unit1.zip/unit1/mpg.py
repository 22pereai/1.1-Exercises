#!/usr/bin/env python3

# display a welcome message
print("The Miles Per Gallon program")
print()

# get input from the user
miles_driven= float(input("Enter miles driven:\t\t"))
gallons_used = float(input("Enter gallons of gas used:\t"))
cost = float(input("Enter cost per gallon:\t"))

# calculate miles per gallon
mpg = miles_driven / gallons_used
mpg = round(mpg, 1)

# calculate total gas cost
total = gallons_used * cost
total = round(total, 1)

# calculate cost per mile
cpm = total / miles_driven
cpm = round(cpm, 1)
            
# format and display the result
print()
print("Miles Per Gallon:\t\t" + str(mpg))
print()
print("Total Cost:\t\t" + str(total))
print()
print("Cost Per Mile:\t\t" + str(cpm))
print()
print("Bye")


