#!/usr/bin/env python3

# display a welcome message
print("Perimiter and Area")
print()

# get input from the user
l = float(input("Enter rectangle length:\t"))
w = float(input("Enter rectangle width:\t"))

# calculations
perimiter = ((2 * l) + (2 * w))
area = (l * w)

            
# format and display the result
print("=====================================================")
print("Perimiter:\t" + str(perimiter))
print()
print("Area:\t" + str(area))
print()
print("Bye")


